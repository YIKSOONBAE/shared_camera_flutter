package com.example.ex_webrtc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
